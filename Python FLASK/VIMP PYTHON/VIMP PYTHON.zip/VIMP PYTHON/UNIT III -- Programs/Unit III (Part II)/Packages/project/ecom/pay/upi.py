class UPI:
	def __init__(s): print('UPI')