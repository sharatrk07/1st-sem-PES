from ecom.db import Database
db = Database()

from ecom.pay.upi import UPI
u = UPI()