class CC:
	def __init__(s): print('Credit Card')