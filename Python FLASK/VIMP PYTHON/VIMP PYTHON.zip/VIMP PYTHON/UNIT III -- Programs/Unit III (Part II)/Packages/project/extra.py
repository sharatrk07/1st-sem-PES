class Extra:
	def __init__(s): print('Extra')