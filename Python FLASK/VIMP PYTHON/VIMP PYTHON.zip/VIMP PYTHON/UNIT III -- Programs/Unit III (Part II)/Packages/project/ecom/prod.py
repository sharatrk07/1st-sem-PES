class Product:
	def __init__(s): print('Product')


from ..extra import Extra
e = Extra()
