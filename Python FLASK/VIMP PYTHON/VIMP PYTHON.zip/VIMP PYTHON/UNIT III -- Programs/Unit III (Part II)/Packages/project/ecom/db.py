class Database:
	def __init__(s): print('Database')