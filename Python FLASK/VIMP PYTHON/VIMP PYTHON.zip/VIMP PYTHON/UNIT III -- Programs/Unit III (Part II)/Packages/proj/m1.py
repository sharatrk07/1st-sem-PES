class A:
	def __init__(s, a):
		s.a = a
	def disp(s):
		print(s.a)

def foo():
	print('foo')
