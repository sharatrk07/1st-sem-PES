from m1 import foo
foo()
a = A(100)