import m1
a = m1.A(10)
a.disp()
m1.foo()