from m1 import *
a = A(100)
a.disp()
foo()