import Package1
print('Double import')