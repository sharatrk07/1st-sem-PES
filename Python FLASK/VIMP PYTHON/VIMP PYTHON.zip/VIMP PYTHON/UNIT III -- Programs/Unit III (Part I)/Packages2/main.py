from .S1 import m1
print('main')