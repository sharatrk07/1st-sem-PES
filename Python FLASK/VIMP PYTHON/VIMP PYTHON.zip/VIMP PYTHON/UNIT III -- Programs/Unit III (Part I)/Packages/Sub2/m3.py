print('m3')
def foo():
	print('AAAA')