import const as c
# from const import foo, A
c.foo()
c.A = 10
c.foo()
print(c.A)
# foo()
