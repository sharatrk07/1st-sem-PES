A = 5
def foo():
	print(A)

foo()