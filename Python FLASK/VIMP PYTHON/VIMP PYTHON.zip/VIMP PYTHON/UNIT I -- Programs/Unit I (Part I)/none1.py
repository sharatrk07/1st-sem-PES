A = None
print(A)
print(id(A))
print(type(A))
B = None
print(id(B))