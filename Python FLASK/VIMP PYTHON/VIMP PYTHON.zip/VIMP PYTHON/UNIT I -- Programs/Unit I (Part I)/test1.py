a = 5
b = 5
print(id(a))
print(id(b))